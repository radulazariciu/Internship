﻿
tinyMCE.addI18n('en.epiquote_dlg', {
    title: "Insert quote",
    titleupdate: "Update quote",
    legendtype: "Type of Quote",
    legendinformation: "Information",
    blockquote: "Blockquote",
    quote: "Quote",
    remove: "Remove",
    update: "Update",
    titlelabel: "Title:",
    citelabel: "Cite:",
    invalidselectionforq: "To avoid invalid HTML you can't insert a q element at the current selection."
});